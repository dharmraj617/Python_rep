list1=[2,4,10,1]
list1.sort(reverse=True)
print(list1[0],list1[1])
