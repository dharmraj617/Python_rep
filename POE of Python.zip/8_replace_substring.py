string=input("Enter the String:")

str1=string.replace("very good","excellent")
str2=str1.replace("good","very good")
str3=str2.replace("bad","good")
print(str3)