list1 = ["M", "na", "i", "Ke"]
list2 = ["y", "me", "s", "lly"]
list3=[]
list4=[]
p=len(list1)
for i in range(0,p):
    list3=list1[i]+list2[i]
    list4.append(list3)

print(list4)
